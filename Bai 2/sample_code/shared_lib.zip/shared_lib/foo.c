#include <stdio.h>

void foo()
{
    printf("Hello, I'm a shared library");
}
